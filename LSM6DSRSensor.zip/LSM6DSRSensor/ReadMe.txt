
  LSM6DSR_Enable();
  LSM6DSR_Enable_X();
  LSM6DSR_Enable_G();
  
  
  /* Read accelerometer and gyroscope. */
  int32_t accelerometer[3];
  int32_t gyroscope[3];
  LSM6DSR_Get_X_Axes(accelerometer);
  LSM6DSR_Get_G_Axes(gyroscope);