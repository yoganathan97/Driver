/*
 * CircularBuf.c
 *
 *  Created on: Jan 20, 2022
 *      Author: Yoganathan V
 */

/* Includes ------------------------------------------------------------------*/
#include "CircularBuf.h"
#include "main.h"
#include "string.h"

/* Private includes ----------------------------------------------------------*/

/* Private typedef -----------------------------------------------------------*/
Typedef_Handle_Uart_S g_CircularBuf_S;

/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/

/* Private user code ---------------------------------------------------------*/

Bool_E CircularBuffer_Init(uint16_t size)
{
	g_CircularBuf_S.Ptr = malloc(size * sizeof(uint8_t));
	if(g_CircularBuf_S.Ptr == NULL) {
		return False;
	}
	g_CircularBuf_S.MaxSize = size;
	g_CircularBuf_S.rxByte = 0;
	g_CircularBuf_S.head = 0;
	g_CircularBuf_S.tail = 0;
	g_CircularBuf_S.rxFlag = False;

	memset((char *)g_CircularBuf_S.Ptr, 0, g_CircularBuf_S.MaxSize);
	return True;

}

void PushData(void)
{
	if(g_CircularBuf_S.tail >= g_CircularBuf_S.MaxSize) {
		g_CircularBuf_S.tail = 0;
	}
	g_CircularBuf_S.Ptr[g_CircularBuf_S.tail++] = g_CircularBuf_S.rxByte;

}

uint16_t GetData(uint8_t *Ptr)
{
	uint16_t n = 0, localHead=g_CircularBuf_S.head, localTail = g_CircularBuf_S.tail;
	uint16_t Cnt = 0;
	/* No Data Available */
	if(g_CircularBuf_S.head == g_CircularBuf_S.tail) {
		return 0;
	}
	/* Get the available Data */
	for(n=localHead; n<g_CircularBuf_S.MaxSize; n++) {
		Ptr[Cnt++] = g_CircularBuf_S.Ptr[g_CircularBuf_S.head];
		g_CircularBuf_S.Ptr[g_CircularBuf_S.head++] = 0;
		if(g_CircularBuf_S.head == localTail) {
			break;
		}
	}
	if(g_CircularBuf_S.head >= g_CircularBuf_S.MaxSize) {
		g_CircularBuf_S.head = 0;
	}
	return (Cnt);
}


