/*
 * CircularBuf.h
 *
 *  Created on: Jan 20, 2022
 *      Author: Yoganathan V
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CIRCULARBUF_CIRCULARBUF_H_
#define CIRCULARBUF_CIRCULARBUF_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stdio.h"
#include "stdlib.h"

/* Private includes ----------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/

typedef enum
{
	False = 0,
	True
}Bool_E;

typedef struct
{
	uint8_t 	*Ptr;
	uint8_t 	rxByte;
	Bool_E 		rxFlag;
	uint16_t	MaxSize;
	uint16_t 	head;
	uint16_t 	tail;

}Typedef_Handle_Uart_S;

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported Variables --------------------------------------------------------*/
extern Typedef_Handle_Uart_S g_CircularBuf_S;

/* Exported functions prototypes ---------------------------------------------*/
Bool_E CircularBuffer_Init(uint16_t size);
void PushData(void);
uint16_t GetData(uint8_t *Ptr);

/* Private defines -----------------------------------------------------------*/

#ifdef __cplusplus
}
#endif



#endif /* CIRCULARBUF_CIRCULARBUF_H_ */
