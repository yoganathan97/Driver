/*
 * atCmd.c
 *
 *  Created on: Oct 20, 2022
 *      Author: Yoganathan.V
 */

/* Includes ------------------------------------------------------------------*/
#include "atCmd.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* Typedef -------------------------------------------------------------------*/
Gsm_Handle_S 	gsmS 		= {0};					/* LTE receiver Handling		*/
GSM_Handle_E 	gsmHandle 	= GSM_STATE_TEST;		/* LTE State Handling 			*/

/* Define -------------------------------------------------------------------*/

/* Macro --------------------------------------------------------------------*/

/* Variables ----------------------------------------------------------------*/

uint16_t CSQ_Value = 0;

/* Function prototypes ------------------------------------------------------*/

/**
  * @brief Gsm_SendString Function will send the Command.
  * @param  buf cmmand buffer
  * @param  len length of the buffer
  * @retval none
  */
static void Gsm_SendString(uint8_t *buf, uint16_t len)
{
    UartPrintf((uint8_t *)buf, len);
}


/**
  * @brief  Gsm_rxFrameHandle shall Handle the response
  * @param  none
  * @retval Status_E
  */
static Status_E Gsm_rxFrameHandle(void)
{    
	Status_E status = AT_Busy;

	if(gsmHandle < GSM_STATE_TCPSTART) {

		if(strstr((char *)gsmS.Buf, "+CSQ:")) {
			if(strstr((char *)gsmS.Buf, "99,99")) {
				status = AT_Busy;

			}else {
				char i=0, *Ptr = strstr((char *)gsmS.Buf, "+CSQ:");
				Bool_E CSQ_Flag = False;
				for(i=0; i<=20; i++) {
					if(CSQ_Flag) {
						CSQ_Value = ((CSQ_Value * 10) + (Ptr[i] - 0x30));
						if(Ptr[i+1] == 0x2c) {
							break;
						}
					}else if(Ptr[i] == 0x20) {
						CSQ_Flag = True;
						CSQ_Value = 0;
					}
				}
				status = AT_Ok;
			}

		}else if(strstr((char *)gsmS.Buf, "CPIN:")) {
			if(strstr((char *)gsmS.Buf, "READY")) {
				status = AT_Ok;

			}else if(strstr((char *)gsmS.Buf, "SIM REMOVED")) {
				status = AT_Error;
			}

		}else if(strstr((char *)gsmS.Buf, "CME ERROR")) {
			status = AT_Busy;
			
		}else if(strstr((char *)gsmS.Buf, "SIM not inserted")) {
			status = AT_Error;
			
		}else if(strstr((char *)gsmS.Buf, "Network is already opened")) {
			status = AT_Ok;

		}else if(strstr((char *)gsmS.Buf, "ERROR")) {
			status = AT_Error;

		}else if(strstr((char *)gsmS.Buf, "NETOPEN")) {
			if(strstr((char *)gsmS.Buf, "0")) {
				status = AT_Ok;

			}else {
				status = AT_Busy;
				gsmS.Cmd -= 1;
			}

		}else if(strstr((char *)gsmS.Buf, "OK")) {
			if(gsmS.Cmd != 12) {
				status = AT_Ok;
			}

		}else if(strstr((char *)gsmS.Buf, "COPS:")) {
			status = AT_Ok;

		}else if(strstr((char *)gsmS.Buf, "PB DONE")) {
			status = AT_Timeout;

		}else {
			status = AT_Busy;
		}

	}else if(gsmHandle >= GSM_STATE_TCPSTART) {

		if(strstr((char *)gsmS.Buf, ">")) {
			status = AT_Ok;

		}else if(strstr((char *)gsmS.Buf, "ERROR")) {
			status = AT_Error;

		}else if(strstr((char *)gsmS.Buf,  "+IPCLOSE")) {
			status = AT_Error;
			gsmHandle = GSM_STATE_TCPDISCONNECT;

		}else if(strstr((char *)gsmS.Buf, "SERVER DISCONNECTED")) {
			status = AT_Error;
			gsmHandle = GSM_STATE_TCPDISCONNECT;

		}else if(strstr((char *)gsmS.Buf, "CIPOPEN")) {
			if(strstr((char *)gsmS.Buf, "1,0")) {
				status = AT_Ok;

			}else {
				status = AT_Busy;
			}

		}else if(strstr((char *)gsmS.Buf, "RECV")) {
			gsmS.MaxWaittime = MAX_RESPONSE_WAITTIME;
			status = AT_Ok;

		}else if(strstr((char *)gsmS.Buf, "CIPSEND")) {
			status = AT_Ok;

		}else if(strstr((char *)gsmS.Buf, "CIPCLOSE")) {
			status = AT_Ok;
			gsmHandle = GSM_STATE_TCPDISCONNECT;

		}else if(strstr((char *)gsmS.Buf, "CPIN:")) {
			if(strstr((char *)gsmS.Buf, "READY")) {
				status = AT_Ok;
			}else if(strstr((char *)gsmS.Buf, "SIM REMOVED")) {
				status = AT_Error;
			}

		}else if(strstr((char *)gsmS.Buf, "PB DONE")) {
			status = AT_Busy;

		}else {
			status = AT_Busy;
		}
	}

	memset((char *)gsmS.Buf, 0, gsmS.tailCnt);
	gsmS.rxFlag = False;
	gsmS.tailCnt = 0;
	return status;
}

/**
  * @brief  Gsm_responseComplete shall Check the response 
  				with timeout
  * @param  timeout
  * @retval Status_E
  */
static Status_E Gsm_responseComplete(uint32_t timeout)
{
	static Bool_E timeoutFlag = False;
	Status_E status = AT_Busy;

	/* Check response received from server */
	if(gsmS.rxFlag) {
		timeoutFlag = False;
		return Gsm_rxFrameHandle();
	}

	if(timeoutFlag == False) {
		gsmS.timeCnt = timeout;
		timeoutFlag = True;

	}else {
		if(0U >= gsmS.timeCnt) {
			timeoutFlag = False;
			status = AT_Timeout;
		}
	}
	return status;
}

/**
  * @brief Gsm Polling process will handle all the recieved and send
	to through GSM. This function should call in loop
  * @param  none
  * @retval none
  */
void Gsm_PollingProcess(void)
{
	static Substatus_E gsmSubstate;
	Status_E Status = AT_Busy;
	static uint8_t retryCnt = 10;

	switch (gsmHandle)
	{
		case GSM_STATE_TEST:
			if(gsmSubstate == Cmd_Send) {
				gsmS.Cmd = 2;
				Gsm_SendString((uint8_t *)atCmd[gsmS.Cmd], strlen(atCmd[gsmS.Cmd]));
				gsmSubstate = Cmd_Waiting;

			}else {
				Status = Gsm_responseComplete(GSM_TIMEOUT);
				if(Status == AT_Timeout) {
					retryCnt--;
					gsmSubstate = Cmd_Send;
					if(retryCnt == 0) {
						gsmState = GSM_ERROR;
					}
				}else if(Status == AT_Ok) {
					gsmS.Cmd += 1;
					retryCnt = 10;
					gsmHandle = GSM_STATE_INIT;
					gsmSubstate = Cmd_Send;
				}
			}
		break;

		case GSM_STATE_RESET:
			if(gsmSubstate == Cmd_Send) {
				gsmS.MaxWaittime = MAX_RESPONSE_WAITTIME;
				Gsm_SendString((uint8_t *)atCmd[1], strlen(atCmd[1]));
				gsmSubstate = Cmd_Waiting;

			}else {
				Status = Gsm_responseComplete(GSM_REBOOT_TIMEOUT);
				if(Status == AT_Timeout) {
					gsmSubstate = Cmd_Send;
					gsmHandle = GSM_STATE_TEST;
				}
			}
		break;

		case GSM_STATE_INIT:
			if(gsmSubstate == Cmd_Send) {
				Gsm_SendString((uint8_t *)atCmd[gsmS.Cmd], strlen(atCmd[gsmS.Cmd]));
				gsmSubstate = Cmd_Waiting;

			}else {
				Status = Gsm_responseComplete(GSM_NTWK_TIMEOUT);
				if((Status == AT_Timeout)) {
					gsmSubstate = Cmd_Send;
					retryCnt--;
				}else if(Status == AT_Ok) {
					gsmSubstate = Cmd_Send;
					gsmS.Cmd += 1;
					retryCnt = 10;
					if(gsmS.Cmd >= TCPSTART_CMD_ADD) {
						gsmHandle = GSM_STATE_TCPSTART;
					}
				}
			}
		break;

		case GSM_STATE_TCPSTART:
			if(gsmSubstate == Cmd_Send) {
				Gsm_SendString((uint8_t *)atCmd[gsmS.Cmd], strlen(atCmd[gsmS.Cmd]));
				gsmSubstate = Cmd_Waiting;

			}else {
				Status = Gsm_responseComplete(GSM_NTWK_TIMEOUT);
				if(Status == AT_Timeout) {
					gsmSubstate = Cmd_Send;
					retryCnt--;
				}else if(Status == AT_Ok) {
					gsmSubstate = Cmd_Send;
					gsmS.Cmd += 1;
					retryCnt = 10;
					if(gsmS.Cmd >= TCPSEND_CMD_ADD) {
						gsmHandle = GSM_STATE_TCPIDLE;
					}
				}
			}
		break;

		case GSM_STATE_TCPSEND:

			if(gsmSubstate == Cmd_Send) {
				Gsm_SendString((uint8_t *)atCmd[gsmS.Cmd], strlen(atCmd[gsmS.Cmd]));
				gsmSubstate = Cmd_Waiting;

			}else {
				Status = Gsm_responseComplete(TCP_SEND_WAITTIME);
				if((Status == AT_Timeout) || (Status == AT_Ok)) {
					Gsm_SendString((uint8_t *)tcpS.Buf, tcpS.len);
					gsmHandle = GSM_STATE_TCPIDLE;
					gsmSubstate = Cmd_Send;
					tcpS.txFlag = False;
				}
			}
		break;

		case GSM_STATE_TCPIDLE:
			if(gsmS.rxFlag == True) {
				Status = Gsm_rxFrameHandle();
			}

		break;

		case GSM_STATE_TCPDISCONNECT:
			if(gsmSubstate == Cmd_Send) {
				Gsm_SendString((uint8_t *)atCmd[TCPDISCONNECT_CMD_ADD], strlen(atCmd[TCPDISCONNECT_CMD_ADD]));
				gsmSubstate = Cmd_Waiting;

			}else {
				Status = Gsm_responseComplete(GSM_TIMEOUT);
				if((Status == AT_Timeout) || (Status == AT_Ok)) {
					gsmHandle = GSM_STATE_TCPSTART;
					gsmSubstate = Cmd_Send;
				}
			}
		break;

		default:
			gsmHandle = GSM_STATE_RESET;
			gsmSubstate = Cmd_Send;
		break;
	}

	if((Status == AT_Error) || (retryCnt == 0U) || (!gsmS.MaxWaittime)) {
		gsmHandle = GSM_STATE_RESET;
		gsmSubstate = Cmd_Send;
		retryCnt = 10;
	}
}

/**
  * @brief Gsm rx Callback Function
  * @param  rxByte received Byte
  * @retval none
  */
void Gsm_rxCallback(uint8_t rxByte)
{
	gsmS.Buf[gsmS.tailCnt++] = rxByte;
	gsmS.rxEnd = True;
	gsmS.rxDelay = GSM_RX_WAITTIME;
}

/**
  * @brief Gsm Command Send End Function
  * @param  none
  * @retval none
  */
void Gsm_Cmd_SendEndCallback(void)
{
	gsmS.sendEnd = True;
}

/**
  * @brief Gsm timer Callback Function
  * @param  none
  * @retval none
  */
void Gsm_Timer1MSCallback(void)
{
	if((gsmS.rxEnd == True) && (gsmS.rxDelay != 0U)) {
		gsmS.rxDelay--;
		if(!gsmS.rxDelay) {
			gsmS.rxFlag = True;
			gsmS.rxEnd = False;
		}
	}
}

/*********************************END OF FILE*********************************/