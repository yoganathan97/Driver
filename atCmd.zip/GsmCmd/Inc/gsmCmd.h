/*
 * gsmCmd.h
 *
 *  Created on: Oct 19, 2022
 *      Author: Yoganathan.V
 */
	
/* Define to prevent recursive inclusion -----------------------------*/
#ifndef INC_GSMCMD_H_
#define INC_GSMCMD_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------*/
#include "string.h"


/* Define ------------------------------------------------------------*/

/* Macro -------------------------------------------------------------*/

#define TCPSTART_CMD_ADD			13
#define TCPSEND_CMD_ADD				14
#define TCPDISCONNECT_CMD_ADD		15

/* Typedef -----------------------------------------------------------*/

char* atCmd[] =
{
    "\r\n",
    "AT+RESET\r\n",
    "AT\r\n",
    "ATE0\r\n",
    "AT+CPIN?\r\n",
    "AT+CSQ\r\n",
    "AT+COPS?\r\n",
    "AT+CREG?\r\n",
    "AT+CGQREQ?\r\n",
    "AT+CGATT?\r\n",
    "AT+CGQMIN?\r\n",
    "AT+CMGF=1\r\n",
    "AT+NETOPEN\r\n",
    "AT+CIPOPEN=1,\"TCP\",\"000.00.000.000\",8080\r\n",
    "AT+CIPSEND=1,290\r\n",
    "AT+CIPCLOSE=1\r\n",
    "AT+NETCLOSE\r\n",
};


/* Variables ---------------------------------------------------------*/

/* Function prototypes -----------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /* INC_GSMCMD_H_ */