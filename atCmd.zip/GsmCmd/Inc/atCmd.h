/*
 * atCmd.h
 *
 *  Created on: Oct 20, 2022
 *      Author: Yoganathan.V
 */
	
/* Define to prevent recursive inclusion -----------------------------*/

#ifndef INC_ATCMD_H_
#define INC_ATCMD_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------*/
#include "stdint.h"

/* Define ------------------------------------------------------------*/

#define GSM_SMS_TIMEOUT				500			/* TCP command Sending Timeout - Init	*/
#define GSM_TIMEOUT					1000		/* TCP command Sending Timeout - Init	*/
#define GSM_NTWK_TIMEOUT			8000		/* TCP command Sending Timeout - NWK	*/
#define GSM_REBOOT_TIMEOUT			10000		/* GSM rebooting Timeout 		*/
#define TCP_SEND_WAITTIME			500			/* Waitime for TCP Payload Sending	*/

#define RX_BUF_MAX_CNT				1000		/* Maximum receive Byte length		*/
#define RX_BUF_SIZE					1004		/* Waitime for GSM Payload receiving	*/
#define GSM_RX_WAITTIME 			50			/* Waitime for Uart Payload receiving	*/
#define TCP_SEND_TIMEINTERVAL		50			/* Interval for Next command Sending	*/

#define MAX_RESPONSE_WAITTIME		18000		/* Waittime for No response in *500mS	*/
#define GSM_FIRMWARE_TIMEOUT		15000		/* Update Firmware Timeout in MilliSec	*/

/* Macro -------------------------------------------------------------*/



/* Typedef -----------------------------------------------------------*/

/*
 * @brief Enum can handle GSM States
 */
typedef enum
{
    GSM_STATE_TEST = 0,
    GSM_STATE_RESET,
    GSM_STATE_INIT,
    GSM_STATE_TCPSTART,
    GSM_STATE_TCPSEND,
    GSM_STATE_TCPDISCONNECT,
    GSM_STATE_TCPIDLE

}GSM_Handle_E;

/**
  * @brief Status Enum definition
  */
typedef enum
{
    Cmd_Send,
    Cmd_Waiting

}Substatus_E;

/**
  * @brief Status Enum definition
  */
typedef enum
{
    AT_Ok = 0,
    AT_Error,
    AT_Busy,
    AT_Timeout,

}Status_E;

/**
  * @brief Bool_E Enum definition
  */
typedef enum
{
    False = 0,
	True

}Bool_E;


/*
 * Struct can handle USART receive Bytes
 * @brief
 */
typedef struct
{
    volatile uint8_t 	Buf[RX_BUF_SIZE];
    volatile uint8_t 	rxByte;
    volatile uint8_t 	Cmd;
    volatile uint8_t 	rxDelay;
    volatile uint16_t 	timeCnt;
    volatile uint16_t 	MaxWaittime;
	volatile Bool_E 	rxFlag;
    volatile unsigned 	HeadCnt			: 15;
    volatile unsigned 	sendEnd			:  1;
    volatile unsigned 	tailCnt 		: 15;
    volatile unsigned 	rxEnd			:  1;

}Gsm_Handle_S;

/* Variables ---------------------------------------------------------*/
extern GSM_Handle_E 	gsmHandle;
extern Gsm_Handle_S 	gsmS;

/* Function prototypes -----------------------------------------------*/
void Gsm_PollingProcess(void);
void Gsm_rxCallback(uint8_t rxByte);
void Gsm_Timer1MSCallback(void);
void Gsm_Cmd_SendEndCallback(void);



#ifdef __cplusplus
}
#endif


#endif /* INC_OCPP_H_ */